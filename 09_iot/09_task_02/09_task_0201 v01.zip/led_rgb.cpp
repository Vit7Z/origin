#include "led_rgb.h"

LedRgb::LedRgb (uint8_t pinR, uint8_t pinG, uint8_t pinB):
  pinR_(pinR), pinG_(pinG), pinB_(pinB),
  brightR_(0), brightG_(0), brightB_(0) {
  pinMode(pinR_, OUTPUT);
  pinMode(pinG_, OUTPUT);
  pinMode(pinB_, OUTPUT);
}

void LedRgb::setColorDigit (bool val_1, bool val_2, bool val_3) {
  digitalWrite(pinR_, val_1);
  digitalWrite(pinG_, val_2);
  digitalWrite(pinB_, val_3);
}