#ifndef LedRgb_h
#define LedRgb_h
#include "Arduino.h"

class LedRgb {
  public:
    LedRgb(uint8_t pinR, uint8_t pinG, uint8_t pinB);

    void setColorDigit(bool val_1, bool val_2, bool val_3);

  private:
    uint8_t pinR_, pinG_, pinB_;
    uint8_t brightR_, brightG_, brightB_;
};

#endif // !LedRGB_h