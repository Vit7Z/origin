#ifndef LedRgb_h
#define LedRgb_h
#include "Arduino.h"

class LedRgb {
  public:
    LedRgb(uint8_t pinR, uint8_t pinG, uint8_t pinB);

    uint8_t checkBright(uint8_t& bright, int8_t diff);
    void setColorR (int8_t diff);
    void setColorG (int8_t diff);
    void setColorB (int8_t diff);

  private:
    uint8_t pinR_, pinG_, pinB_;
    uint8_t brightR_, brightG_, brightB_;
};

#endif // !LedRGB_h