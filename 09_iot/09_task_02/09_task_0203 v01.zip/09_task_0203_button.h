#ifndef Button_h
#define Button_h
#include "Arduino.h"

//----------------------------------------------
class Button {
  public:
    Button (uint8_t pin);
    void scanState();

    bool currentState_;
    bool lastState_;
    
  private:
    uint8_t pin_;
};

#endif