#include "tempr_sensor.h"

TemprSensor::TemprSensor (uint8_t pin) {
  pin_ = pin;
  pinMode(pin_, INPUT);
}

float TemprSensor::GetTemperatureCels() {
  const float kBeta {3950};
  float value = 1 / (log(1 / (1023. / analogRead(pin_) - 1)) / kBeta + 1.0 / 298.15) - 273.15;
  return value;
}