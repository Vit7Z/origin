#include <math.h>

#ifndef Tempr_sensor_h
#define Tempr_sensor_h
#include "Arduino.h"

//----------------------------------------------
class TemprSensor {
  public:
    TemprSensor (uint8_t pin);
    float GetTemperatureCels();

    ~TemprSensor() {
      Serial.println("TemprSensor deleted");
    }

  private:
    uint8_t pin_;
};

#endif