#include "Arduino.h"

#ifndef LedRGB_h
#define LedRGB_h

class LedRgb {
  public:
    uint8_t brightR_, brightG_, brightB_;
    
    LedRgb(uint8_t pinR, uint8_t pinG, uint8_t pinB);

    void setColor(uint8_t val_1, uint8_t val_2, uint8_t val_3);
    void blink(uint16_t value);
    
  private:
    uint8_t pinR_, pinG_, pinB_;
};

#endif // !LedRGB_h