#include "ultrasonic.h"

Ultrasonic::Ultrasonic (uint8_t pinTrig, uint8_t pinEcho) {
  pinTrig_ = pinTrig;
  pinEcho_ = pinEcho;

  pinMode(pinTrig_, OUTPUT);
  pinMode(pinEcho_, INPUT);
}

float Ultrasonic::GetDistanceMetre() {
  digitalWrite(pinTrig_, LOW);
  delayMicroseconds(2);
  digitalWrite(pinTrig_, HIGH); // установка TRIG на 10 мкс
  delayMicroseconds(10);
  digitalWrite(pinTrig_, LOW);
  pinMode(pinEcho_, INPUT); // измерение длительности ECHO
  distance_in_meters = (pulseIn(pinEcho_, HIGH) / 58) / 100.0;
  return distance_in_meters;
}