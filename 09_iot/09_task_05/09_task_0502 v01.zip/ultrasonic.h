#include "Arduino.h"

#ifndef Ultrasonic_h
#define Ultrasonic_h

class Ultrasonic {
  public:
    float distance_in_meters;

    Ultrasonic(uint8_t pinTrig, uint8_t pinEcho);

    float GetDistanceMetre();

  private:
    uint8_t pinTrig_, pinEcho_;
};

#endif // Ultrasonic_h