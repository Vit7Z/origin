#ifndef Joystick_h
#define Joystick_h
#include "Arduino.h"



//----------------------------------------------
class Joystick {
  public:
    Joystick (uint8_t pin_x, uint8_t pin_y, uint8_t pin_btn);

    short GetY();
    bool GetButtonStatus();

    short delta_y;
    bool btn_status_crnt;

  private:
    uint8_t pin_x_;
    uint8_t pin_y_;
    uint8_t pin_btn_;

    unsigned long timer_y;
    unsigned long timer_button;
};

#endif