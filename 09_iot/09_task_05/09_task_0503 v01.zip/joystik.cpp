#include "joystick.h"

#define DEAD_ZONE 20
#define DELAY 150

Joystick::Joystick (uint8_t pin_x, uint8_t pin_y, uint8_t pin_btn) {

  pin_x_ = pin_x;
  pin_y_ = pin_y;
  pin_btn_ = pin_btn;

  pinMode(pin_x_, INPUT_PULLUP);
  pinMode(pin_y_, INPUT_PULLUP);
  pinMode(pin_btn_, INPUT_PULLUP);

  timer_y = 0;
  timer_button = 0;
  btn_status_crnt = 0;
}

short Joystick::GetY() {
  int Y = analogRead(pin_y_);
  delta_y = 0;
  if (Y < 512 - DEAD_ZONE || Y > 512 + DEAD_ZONE) {
    btn_status_crnt = 0;
    if (millis() - timer_y >= DELAY) {
      if (Y < 512 - DEAD_ZONE || Y > 512 + DEAD_ZONE) {
        if (Y > (512 + DEAD_ZONE)) {
          delta_y = 1;
        } else {
          delta_y = -1;
        }
        timer_y = millis();
      }
    }
  }
  return delta_y;
}


bool Joystick::GetButtonStatus() {
  if (digitalRead(pin_btn_) == LOW) {
    if (millis() - timer_button >= DELAY) {
      if (digitalRead(pin_btn_) == LOW) {
        btn_status_crnt = 1;
        timer_button = millis();
      }
    }
  }
  return btn_status_crnt;
}
