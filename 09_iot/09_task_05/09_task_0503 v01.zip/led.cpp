#include "led.h"

Led::Led (uint8_t pin) {
  pin_ = pin;  
  pinMode(pin_, OUTPUT);
}

void Led::TurnOn () {
  digitalWrite(pin_, HIGH);
}

void Led::TurnOff () {
  digitalWrite(pin_, LOW);
}