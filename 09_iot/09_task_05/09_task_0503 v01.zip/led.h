#ifndef Led_h
#define Led_h
#include "Arduino.h"

class Led {
  public:
    Led(uint8_t pin);

    void TurnOn();
void TurnOff();
  private:
    uint8_t pin_;
};

#endif //Led_h