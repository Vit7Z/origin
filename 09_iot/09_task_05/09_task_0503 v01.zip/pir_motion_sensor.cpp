#include "pir_motion_sensor.h"

PirMotionSensor::PirMotionSensor (uint8_t pin) {
  pin_ = pin;
  pinMode(pin_, INPUT);
}

void PirMotionSensor::GetStatus() {
  status = digitalRead(pin_);
}