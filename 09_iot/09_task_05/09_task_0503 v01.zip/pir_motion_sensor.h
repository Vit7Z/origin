#ifndef PirMotionSensor_h
#define PirMotionSensor_h
#include "Arduino.h"

//----------------------------------------------
class PirMotionSensor {
  public:
    PirMotionSensor (uint8_t pin);
    void GetStatus();
    uint8_t status;

  private:
    uint8_t pin_;    
};

#endif